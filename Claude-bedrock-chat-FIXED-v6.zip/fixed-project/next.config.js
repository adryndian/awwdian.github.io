/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  // HAPUS experimental.serverActions
};

module.exports = nextConfig;
